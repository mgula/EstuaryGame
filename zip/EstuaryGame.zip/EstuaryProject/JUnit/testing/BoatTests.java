package testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class BoatTests {

	@Test
	public void test() {
		
	}

}
