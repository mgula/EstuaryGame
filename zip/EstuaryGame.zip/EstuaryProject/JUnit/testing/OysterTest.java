package testing;

import static org.junit.Assert.*;

import org.junit.Test;

import minigame2Models.OysterShell;

public class OysterTest {
	
	@Test
	public void testCoords(){
		
	}
}
