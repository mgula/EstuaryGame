The file hierarchy is relatively self explanatory:

Models: all minigame models as well as games themselves.

Views: all views.

Controller: Main.java uses all packages to tie everything together.

JUnit: JUnit testing suite.

Constants: Enums that most classes will use.

images: a folder containing all images.

UML: UML diagram.

NOTE: the biggest source of existing magic numbers are the methods that make stages
in Minigame1.java. Didn't have time to make each xloc, yloc, height, etc. a variable.