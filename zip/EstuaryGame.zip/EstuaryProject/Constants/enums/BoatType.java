package enums;

public enum BoatType {
	SAILBOAT,
	TANKER,
	SPEEDBOAT;
	
	private BoatType(){};

}
